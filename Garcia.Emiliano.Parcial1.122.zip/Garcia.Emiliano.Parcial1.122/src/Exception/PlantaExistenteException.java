/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exception;

/**
 *
 * @author User
 */
public class PlantaExistenteException extends RuntimeException{
    
    private static final String MESSAGE = "Ya existe una planta con ese nombre y ubicacion";
    
    public PlantaExistenteException(){
        this(MESSAGE);
    }
    
    public PlantaExistenteException(String mensaje){
        super(mensaje);
    }
    
}
