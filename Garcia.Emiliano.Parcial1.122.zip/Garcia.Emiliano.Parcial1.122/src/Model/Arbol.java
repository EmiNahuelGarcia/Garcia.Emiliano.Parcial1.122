/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interfaces.Aromatizador;
import Interfaces.Podable;

/**
 *
 * @author User
 */
public class Arbol extends Planta implements Podable, Aromatizador {
    
    private double altura;
    
    
    public Arbol(String nombre, String ubicacion, String clima, double altura) {
        super(nombre, ubicacion, clima);
        validarAltura(altura);
        this.altura = altura;
    }

    private void validarAltura(double altura){
        double alturaMinima = 0.1; 
        double alturaMaxima = 200.0;
        
        if(!(altura >= alturaMinima && altura <= alturaMaxima)){
            throw new IllegalArgumentException("altura invalida, la altura debe estar entre " + alturaMinima + " y " + alturaMaxima);
            
        }
        
       
    }
    
    @Override
    public void podarPlantas() {
        
        System.out.println("podando " + getNombre());
        
    }

    @Override
    public void desprenderAroma() {
        System.out.println("Desprendiendo aroma " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + ", Altura : " + altura + " metros";
    }
    
    
}
