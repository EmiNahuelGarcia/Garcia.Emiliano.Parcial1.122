/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interfaces.Aromatizador;
import Interfaces.Podable;

/**
 *
 * @author User
 */
public class Arbol extends Planta implements Podable, Aromatizador {
    
    private final static int ALTURA_MAX = 10;
    
    private int altura;
    
    
    public Arbol(String nombre, String ubicacion, String clima, int altura) {
        super(nombre, ubicacion, clima);
        validarAltura(altura);
        this.altura = altura;
    }

    private void validarAltura(int altura){
        if(altura > ALTURA_MAX){
            throw new IllegalArgumentException("Altura invalida, la altura maxima es" + ALTURA_MAX);
        }
    }
    
    @Override
    public void podarPlantas() {
        
        System.out.println("podando " + getNombre());
        
    }

    @Override
    public void desprenderAroma() {
        System.out.println("Desprendiendo aroma " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + " Altura : " + altura + " metros";
    }
    
    
}
