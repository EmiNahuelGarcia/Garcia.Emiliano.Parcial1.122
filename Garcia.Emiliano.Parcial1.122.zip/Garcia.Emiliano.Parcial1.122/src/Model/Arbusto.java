/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interfaces.Podable;

/**
 *
 * @author User
 */
public class Arbusto extends Planta implements Podable {
    
    private final static int DENSIDAD_MAX = 10;
    private final static int DENSIDAD_MIN = 1;
    
    private int densidad;

    public Arbusto(String nombre, String ubicacion, String clima, int densidad) {
        super(nombre, ubicacion, clima);
        validarDensidad(densidad);
        this.densidad = densidad;
    }

    private void validarDensidad(int densidad) {
    if (!(densidad >= DENSIDAD_MIN && densidad <= DENSIDAD_MAX)) {
        throw new IllegalArgumentException("Densidad invalida, debe estar entre " 
                    + DENSIDAD_MIN + " y " + DENSIDAD_MAX);
    }
}
    
    @Override
    public void podarPlantas() {
        System.out.println("podando con mas cuidado " + getNombre());
        
    }
    
    @Override
    public String toString() {
        return super.toString() + ", Densidad del Follaje: " + densidad;
    }
    
}
