/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interfaces.Aromatizador;

/**
 *
 * @author User
 */
public class Flor extends Planta implements Aromatizador{
    
    private Temporada temporadaDeFlorecimiento;
    
    public Flor(String nombre, String ubicacion, String clima, Temporada temporadaDeFlorecimiento) {
        super(nombre, ubicacion, clima);
        this.temporadaDeFlorecimiento = temporadaDeFlorecimiento;
    }

    @Override
    public void desprenderAroma() {
        System.out.println("Desprendiendo aroma mas dulce " + getNombre());
    }
    
    @Override
    public String toString() {
        return super.toString() + " Temporada de Florecimiento : " + temporadaDeFlorecimiento;
    }

    public Temporada getTemporadaDeFlorecimiento() {
        return temporadaDeFlorecimiento;
    }
    
}
