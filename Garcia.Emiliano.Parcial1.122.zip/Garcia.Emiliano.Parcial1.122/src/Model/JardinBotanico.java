/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Exception.PlantaExistenteException;
import Interfaces.Podable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class JardinBotanico {

    private List<Planta> plantas;

    public JardinBotanico() {
        this.plantas = new ArrayList<>();
    }
    
    
    public void agregarPlanta(Planta planta){
        validarPlanta(planta);
        plantas.add(planta);
    
    }
    
    private void validarPlanta(Planta p) {
        if (p == null) {
            throw new NullPointerException("Planta nula");
        }
        if (plantas.contains(p)) {
            throw new PlantaExistenteException("Esa planta " + p.getNombre() + " con la ubicacion" + p.getUbicacion() + " ya existe");
        }
    }

    
    public void mostrarPlantas(){
        for(int i = 0; i < plantas.size(); i++) {
            System.out.println(plantas.get(i));
        }
    }
    
    private void validarVacia(){
        if(plantas.isEmpty()){
            System.out.println("no hay plantas para podar");
        }
    }
    
    public void podarPlantas(){
        validarVacia();
        for (Planta p : plantas) {
            if (p instanceof Podable podable) {
                podable.podarPlantas();
            }else{
                    System.out.println("planta no podable " + p.getNombre());
            }}
      
        }

    public ArrayList<Flor> filtrarPorTemporadaFlorecimiento(Temporada temporada){
        ArrayList<Flor> floresFiltradas = new ArrayList<>();
    
        for(Planta p : plantas){
            if(p instanceof Flor){
                Flor f = (Flor)p;
                if(f.getTemporadaDeFlorecimiento() == temporada){
                    floresFiltradas.add(f);
                    System.out.println(f);
                }
            
            }
           
        
        }
        return floresFiltradas;
        
    }

    
            
}            
                     
    
    

        

    
    
    


    
    
