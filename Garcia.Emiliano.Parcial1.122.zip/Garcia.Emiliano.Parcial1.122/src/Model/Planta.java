/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.Objects;

/**
 *
 * @author User
 */
public abstract class Planta {
    
    private String nombre;
    private String ubicacion;
    private String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public String getClima() {
        return clima;
    }

    @Override
    public String toString() {
        return "Planta : " + getNombre() + " Ubicacion : " + getUbicacion() + " Clima : " + getClima();
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Planta p)) {
            return false;
        }
        return this.nombre.equals(p.nombre) && this.ubicacion.equals(p.ubicacion);
    }

    @Override
    public int hashCode(){
        return Objects.hash(nombre, ubicacion);
    }
    
 
    
    
    
        
}


