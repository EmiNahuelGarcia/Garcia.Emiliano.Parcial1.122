/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package garcia.emiliano.parcial1.pkg122;

import Exception.PlantaExistenteException;
import Model.Arbol;
import Model.Arbusto;
import Model.Flor;
import Model.JardinBotanico;
import Model.Planta;
import Model.Temporada;


/**
 *
 * @author User
 */
public class GarciaEmilianoParcial1122 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        JardinBotanico Jardin = new JardinBotanico();
        System.out.println("\n--- Agregando plantas ---");
     try{   
        Arbol arbol1 = new Arbol("Roble", "Norte", "templado", 100);
        Arbol arbol2 = new Arbol("Roble", "Norte", "caliente", 9);
        Flor flor1 = new Flor("Jazmin", "sur", "templado", Temporada.PRIMAVERA);
        Arbusto arbusto1 = new Arbusto("Arbusto", "norte", "calido", 5);
        Jardin.agregarPlanta(arbol1);
        Jardin.agregarPlanta(flor1);
        Jardin.agregarPlanta(arbusto1);
        Jardin.agregarPlanta(arbol2);
        } catch (PlantaExistenteException e) {
        System.err.println(e.getMessage());
    }
        
        
        System.out.println("\n--- Mostrando plantas ---");
        Jardin.mostrarPlantas();
        
        System.out.println("\n--- Podando plantas ---");
        Jardin.podarPlantas();
        
        System.out.println("\n--- Filtrando plantas ---");
        Jardin.filtrarPorTemporadaFlorecimiento(Temporada.VERANO);
        Jardin.filtrarPorTemporadaFlorecimiento(Temporada.PRIMAVERA);
        
       
        
        
        
        
     
        
        



        
       
       
    }
    
}
