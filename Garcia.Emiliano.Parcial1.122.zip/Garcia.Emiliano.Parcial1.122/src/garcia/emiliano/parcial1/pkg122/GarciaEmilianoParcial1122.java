/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package garcia.emiliano.parcial1.pkg122;

import Model.Arbol;
import Model.Flor;
import Model.JardinBotanico;
import Model.Temporada;


/**
 *
 * @author User
 */
public class GarciaEmilianoParcial1122 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       
       
    }
    
}
